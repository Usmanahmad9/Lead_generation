from flask import Flask, request, jsonify, render_template
import csv
from datetime import datetime

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    data['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    with open('leads.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([data['name'], data['email'], data['phone'], data['company'], data['interest'], data['timestamp']])
    
    return jsonify({"message": "Lead information saved successfully!"})

if __name__ == '__main__':
    app.run(debug=True)
